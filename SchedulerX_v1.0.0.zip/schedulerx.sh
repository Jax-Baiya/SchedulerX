#!/bin/bash
# SchedulerX CLI Wrapper
python3 run_all.py "$@"